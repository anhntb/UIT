export const monthlyData = [
    {
      month: '12/2024',
      income: 5500000,
      expense: -115000,
    },
    {
      month: '11/2024',
      income: 0,
      expense: 0,
    },
    {
      month: '10/2024',
      income: 0,
      expense: 0,
    },
    {
      month: '9/2024',
      income: 0,
      expense: 0,
    },
  ];
  